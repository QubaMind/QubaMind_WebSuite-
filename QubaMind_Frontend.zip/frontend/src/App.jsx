import React from "react";
import Paraphraser from "./Paraphraser";

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Paraphraser />
    </div>
  );
}

export default App;

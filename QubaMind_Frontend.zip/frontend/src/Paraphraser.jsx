import React, { useState } from "react";
import axios from "axios";

export default function Paraphraser() {
  const [text, setText] = useState("");
  const [mode, setMode] = useState("Formal");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const handleParaphrase = async () => {
    if (!text.trim()) return;
    setLoading(true);
    try {
      const response = await axios.post("http://127.0.0.1:8002/api/paraphrase", {
        text,
        mode,
      });
      setResult(response.data.result);
    } catch (err) {
      setResult("❌ Error: " + (err.response?.data?.detail || "Unknown error"));
    }
    setLoading(false);
  };

  return (
    <div className="max-w-3xl mx-auto p-6 mt-12 rounded-2xl shadow-xl bg-white space-y-4">
      <h1 className="text-3xl font-bold text-blue-800">🧠 QubaMind AI Paraphraser</h1>
      <textarea
        rows={6}
        className="w-full border-2 rounded-lg p-3 text-gray-800 focus:outline-none focus:ring-2"
        placeholder="Type your text here..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <select
        className="w-full border-2 p-2 rounded-lg text-gray-800"
        value={mode}
        onChange={(e) => setMode(e.target.value)}
      >
        <option value="Formal">Formal</option>
        <option value="Simple">Simple</option>
        <option value="Creative">Creative</option>
        <option value="Friendly">Friendly</option>
      </select>
      <button
        onClick={handleParaphrase}
        className="bg-blue-700 hover:bg-blue-900 text-white px-4 py-2 rounded-lg transition disabled:opacity-50"
        disabled={loading}
      >
        {loading ? "Processing..." : "Paraphrase"}
      </button>
      {result && (
        <div className="bg-gray-100 p-4 rounded-xl border text-gray-900 whitespace-pre-wrap">
          <strong>✨ Paraphrased:</strong>
          <p>{result}</p>
        </div>
      )}
    </div>
  );
}

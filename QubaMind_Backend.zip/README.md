# QubaMind Paraphraser Backend

## 🚀 Run Server

```bash
uvicorn main:app --reload --port 8002
```

## 📦 Install Requirements

```bash
pip install -r requirements.txt
```

## 🔐 .env file

Add your Groq API key:

```
GROQ_API_KEY=sk-xxxxxx
```

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from paraphraser import paraphrase_text
import os
from dotenv import load_dotenv

load_dotenv()
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/api/paraphrase")
async def paraphrase_api(request: Request):
    data = await request.json()
    text = data.get("text")
    mode = data.get("mode", "Formal")
    result = await paraphrase_text(text, mode)
    return {"result": result}

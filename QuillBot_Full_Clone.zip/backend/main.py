from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import os
from openai import OpenAI

load_dotenv()

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

client = OpenAI(api_key=os.getenv("GROQ_API_KEY"))

class TextInput(BaseModel):
    text: str
    mode: str

@app.post("/api/paraphrase")
async def paraphrase_text(input: TextInput):
    try:
        messages = [{"role": "user", "content": f"Paraphrase this in {input.mode} mode: {input.text}"}]
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
        )
        return {"result": response.choices[0].message.content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))